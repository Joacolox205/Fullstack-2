-- Datos iniciales del microservicio atenciones
-- Los ids de paciente y nutricionista son los de los datos iniciales de usuarios:
--   nutricionistas: 1 Carolina, 2 Rodrigo, 3 Daniela, 4 Felipe | pacientes: 6 Juan Perez, 7 Halam Dupre

-- Bloques de atencion (los mismos de HORARIOS_POR_NUTRICIONISTA del front)
INSERT INTO horario_nutricionista (id_nutricionista, hora) VALUES
-- Carolina Fuentes
(1, '08:00:00'), (1, '08:30:00'), (1, '09:00:00'), (1, '09:30:00'), (1, '10:00:00'), (1, '10:30:00'), (1, '11:00:00'), (1, '11:30:00'), (1, '12:00:00'), (1, '12:30:00'),
-- Rodrigo Sepulveda
(2, '13:30:00'), (2, '14:00:00'), (2, '14:30:00'), (2, '15:00:00'), (2, '15:30:00'), (2, '16:00:00'), (2, '16:30:00'), (2, '17:00:00'), (2, '17:30:00'), (2, '18:00:00'),
-- Daniela Morales
(3, '09:00:00'), (3, '09:30:00'), (3, '10:00:00'), (3, '10:30:00'), (3, '11:00:00'), (3, '11:30:00'), (3, '12:00:00'), (3, '12:30:00'), (3, '13:00:00'), (3, '13:30:00'),
-- Felipe Araya
(4, '14:00:00'), (4, '14:30:00'), (4, '15:00:00'), (4, '15:30:00'), (4, '16:00:00'), (4, '16:30:00'), (4, '17:00:00'), (4, '17:30:00'), (4, '18:00:00');

-- Citas de ejemplo para la pagina Pacientes (precio copiado del servicio)
INSERT INTO cita (id_paciente, id_nutricionista, id_servicio, fecha, hora, motivo, precio, estado, fecha_creacion) VALUES
(7, 1, 1, '2026-11-20', '09:00:00', 'Quiero bajar de peso', 35000, 'Confirmada', NOW()),
(6, 1, 2, '2026-11-21', '10:30:00', 'Control mensual', 25000, 'Pendiente', NOW());

-- Fichas clinicas de ejemplo (una por paciente)
INSERT INTO ficha_clinica (id_paciente, peso_kg, estatura_m, diagnostico, fecha_actualizacion) VALUES
(7, 78.50, 1.72, 'Paciente en plan de déficit calórico moderado. Presenta antecedentes de hipertensión leve.', NOW()),
(6, 82.00, 1.80, 'Control mensual. Buena adherencia al plan vegetariano y reducción de porcentaje graso.', NOW());
