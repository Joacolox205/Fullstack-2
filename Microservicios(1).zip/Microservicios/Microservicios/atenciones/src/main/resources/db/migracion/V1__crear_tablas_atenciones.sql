-- Tablas del microservicio atenciones
-- id_paciente, id_nutricionista e id_servicio son REFERENCIAS LOGICAS:
-- apuntan a tablas de otros microservicios, por eso NO llevan FOREIGN KEY

CREATE TABLE horario_nutricionista(
    id_horario_nutricionista BIGINT NOT NULL AUTO_INCREMENT,
    id_nutricionista BIGINT NOT NULL,
    hora TIME NOT NULL,
    PRIMARY KEY (id_horario_nutricionista),
    CONSTRAINT uk_horario_nutricionista_hora UNIQUE (id_nutricionista, hora)
);

CREATE TABLE cita(
    id_cita BIGINT NOT NULL AUTO_INCREMENT,
    id_paciente BIGINT NOT NULL,
    id_nutricionista BIGINT NOT NULL,
    id_servicio BIGINT NOT NULL,
    fecha DATE NOT NULL,
    hora TIME NOT NULL,
    motivo VARCHAR(500) NULL,
    precio INT NOT NULL,
    estado VARCHAR(20) NOT NULL DEFAULT 'Pendiente',
    fecha_creacion DATETIME NOT NULL,
    PRIMARY KEY (id_cita)
);

CREATE TABLE ficha_clinica(
    id_ficha_clinica BIGINT NOT NULL AUTO_INCREMENT,
    id_paciente BIGINT NOT NULL,
    peso_kg DECIMAL(5,2) NULL,
    estatura_m DECIMAL(3,2) NULL,
    diagnostico TEXT NULL,
    fecha_actualizacion DATETIME NOT NULL,
    PRIMARY KEY (id_ficha_clinica),
    CONSTRAINT uk_ficha_clinica_paciente UNIQUE (id_paciente)
);
