package cl.nutrivida.atenciones.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

// Respuesta de la ficha clinica (si el paciente aun no tiene ficha, los datos vienen en null)
@Data
public class FichaDTO {
    private Long id;
    private Long idPaciente;
    private String nombrePaciente;
    private String rutPaciente;
    private BigDecimal pesoKg;
    private BigDecimal estaturaM;
    private String diagnostico;
    private LocalDateTime fechaActualizacion;
}
