package cl.nutrivida.atenciones.controller;

import cl.nutrivida.atenciones.dto.FichaDTO;
import cl.nutrivida.atenciones.dto.FichaEntradaDTO;
import cl.nutrivida.atenciones.service.FichaService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/fichas")
public class FichaController {

    private final FichaService fichaService;

    public FichaController(FichaService fichaService) {
        this.fichaService = fichaService;
    }

    // GET /api/fichas/paciente/7?idUsuario=2
    @GetMapping("/paciente/{idPaciente}")
    public ResponseEntity<FichaDTO> obtener(@PathVariable Long idPaciente, @RequestParam Long idUsuario) {
        return ResponseEntity.ok(fichaService.obtener(idPaciente, idUsuario));
    }

    // PUT crea la ficha si no existe, o la actualiza si ya existe
    @PutMapping("/paciente/{idPaciente}")
    public ResponseEntity<FichaDTO> guardar(@PathVariable Long idPaciente, @Valid @RequestBody FichaEntradaDTO dto,
                                            @RequestParam Long idUsuario) {
        return ResponseEntity.ok(fichaService.guardar(idPaciente, dto, idUsuario));
    }
}
