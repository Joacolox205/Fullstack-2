package cl.nutrivida.atenciones.controller;

import cl.nutrivida.atenciones.dto.HorarioEntradaDTO;
import cl.nutrivida.atenciones.model.HorarioNutricionista;
import cl.nutrivida.atenciones.service.HorarioService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/horarios")
public class HorarioController {

    private final HorarioService horarioService;

    public HorarioController(HorarioService horarioService) {
        this.horarioService = horarioService;
    }

    @GetMapping("/nutricionista/{idNutricionista}")
    public ResponseEntity<List<HorarioNutricionista>> listar(@PathVariable Long idNutricionista) {
        return ResponseEntity.ok(horarioService.listar(idNutricionista));
    }

    // POST /api/horarios?idAdmin=1  body: {"idNutricionista": 1, "hora": "13:00"}
    @PostMapping
    public ResponseEntity<HorarioNutricionista> crear(@Valid @RequestBody HorarioEntradaDTO dto,
                                                      @RequestParam Long idAdmin) {
        return ResponseEntity.status(HttpStatus.CREATED).body(horarioService.crear(dto, idAdmin));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id, @RequestParam Long idAdmin) {
        horarioService.eliminar(id, idAdmin);
        return ResponseEntity.noContent().build();
    }
}
