package cl.nutrivida.atenciones.dto;

import lombok.Data;

// Respuesta para los KPIs del panel de administracion
@Data
public class ResumenCitasDTO {
    private Long citasHoy;
    private Long citasPendientes;
    private Long ingresosMes;
}
