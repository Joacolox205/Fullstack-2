package cl.nutrivida.atenciones.repository;

import cl.nutrivida.atenciones.model.HorarioNutricionista;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalTime;
import java.util.List;

public interface HorarioNutricionistaRepository extends JpaRepository<HorarioNutricionista, Long> {

    List<HorarioNutricionista> findByIdNutricionistaOrderByHoraAsc(Long idNutricionista);

    boolean existsByIdNutricionistaAndHora(Long idNutricionista, LocalTime hora);
}
