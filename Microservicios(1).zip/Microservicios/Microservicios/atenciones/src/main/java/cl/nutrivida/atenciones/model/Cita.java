package cl.nutrivida.atenciones.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

// Reserva de hora de un paciente (pagina Agendar)
@Data
@Entity
@Table(name = "cita")
public class Cita {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_cita")
    private Long id;

    // Referencia logica -> usuarios.usuario (solo se guarda el id)
    @Column(name = "id_paciente", nullable = false)
    private Long idPaciente;

    // Referencia logica -> usuarios.nutricionista
    @Column(name = "id_nutricionista", nullable = false)
    private Long idNutricionista;

    // Referencia logica -> contenido.servicio
    @Column(name = "id_servicio", nullable = false)
    private Long idServicio;

    @Column(name = "fecha", nullable = false)
    private LocalDate fecha;

    @Column(name = "hora", nullable = false)
    private LocalTime hora;

    @Column(name = "motivo", length = 500)
    private String motivo;

    // Precio acordado al reservar: se COPIA desde contenido, no desde el front
    @Column(name = "precio", nullable = false)
    private Integer precio;

    // Pendiente, Confirmada, Atendida o Cancelada
    @Column(name = "estado", nullable = false, length = 20)
    private String estado = "Pendiente";

    @Column(name = "fecha_creacion", nullable = false)
    private LocalDateTime fechaCreacion;

    @PrePersist
    public void prePersist() {
        this.fechaCreacion = LocalDateTime.now();
    }
}
