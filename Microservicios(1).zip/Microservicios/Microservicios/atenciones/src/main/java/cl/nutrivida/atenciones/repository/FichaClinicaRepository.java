package cl.nutrivida.atenciones.repository;

import cl.nutrivida.atenciones.model.FichaClinica;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface FichaClinicaRepository extends JpaRepository<FichaClinica, Long> {

    Optional<FichaClinica> findByIdPaciente(Long idPaciente);
}
