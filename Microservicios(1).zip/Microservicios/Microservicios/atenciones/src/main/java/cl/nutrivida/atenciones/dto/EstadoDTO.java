package cl.nutrivida.atenciones.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

// Entrada para cambiar el estado de una cita (Confirmada, Atendida o Cancelada)
@Data
public class EstadoDTO {

    @NotBlank(message = "Debe indicar el nuevo estado.")
    private String estado;
}
