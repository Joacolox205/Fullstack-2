package cl.nutrivida.atenciones.model;

import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

// Una ficha por paciente; el nutricionista la va actualizando (pagina Pacientes)
@Data
@Entity
@Table(name = "ficha_clinica")
public class FichaClinica {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_ficha_clinica")
    private Long id;

    // Referencia logica -> usuarios.usuario. UNIQUE: una sola ficha por paciente
    @Column(name = "id_paciente", nullable = false, unique = true)
    private Long idPaciente;

    // BigDecimal porque en MySQL es DECIMAL (numero exacto con decimales)
    @Column(name = "peso_kg", precision = 5, scale = 2)
    private BigDecimal pesoKg;

    @Column(name = "estatura_m", precision = 3, scale = 2)
    private BigDecimal estaturaM;

    @Column(name = "diagnostico", columnDefinition = "TEXT")
    private String diagnostico;

    @Column(name = "fecha_actualizacion", nullable = false)
    private LocalDateTime fechaActualizacion;

    // Se actualiza sola al crear y cada vez que se modifica
    @PrePersist
    @PreUpdate
    public void actualizarFecha() {
        this.fechaActualizacion = LocalDateTime.now();
    }
}
