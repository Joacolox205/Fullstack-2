package cl.nutrivida.atenciones.repository;

import cl.nutrivida.atenciones.model.Cita;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public interface CitaRepository extends JpaRepository<Cita, Long> {

    // Listados segun el rol (ordenados por fecha y hora)
    List<Cita> findAllByOrderByFechaAscHoraAsc();

    List<Cita> findByIdPacienteOrderByFechaAscHoraAsc(Long idPaciente);

    List<Cita> findByIdNutricionistaOrderByFechaAscHoraAsc(Long idNutricionista);

    // "No tener dos reservas a la misma hora" (las canceladas no cuentan)
    boolean existsByIdNutricionistaAndFechaAndHoraAndEstadoNot(Long idNutricionista, LocalDate fecha,
                                                               LocalTime hora, String estado);

    boolean existsByIdPacienteAndFechaAndHoraAndEstadoNot(Long idPaciente, LocalDate fecha,
                                                          LocalTime hora, String estado);

    // Citas tomadas de un nutricionista en un dia (para calcular horas libres)
    List<Cita> findByIdNutricionistaAndFechaAndEstadoNot(Long idNutricionista, LocalDate fecha, String estado);

    // KPIs del panel de administracion
    long countByFechaAndEstadoNot(LocalDate fecha, String estado);

    long countByEstado(String estado);

    List<Cita> findByFechaBetweenAndEstadoNot(LocalDate desde, LocalDate hasta, String estado);
}
