package cl.nutrivida.atenciones.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalTime;

// Un bloque de atencion de un nutricionista (una fila por hora, asi se cumple la 1FN)
@Data
@Entity
@Table(name = "horario_nutricionista")
public class HorarioNutricionista {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_horario_nutricionista")
    private Long id;

    // Referencia logica -> usuarios.nutricionista
    @Column(name = "id_nutricionista", nullable = false)
    private Long idNutricionista;

    @Column(name = "hora", nullable = false)
    private LocalTime hora;
}
