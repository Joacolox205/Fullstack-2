package cl.nutrivida.atenciones.dto;

import lombok.Data;

// Lo que responde el microservicio contenido en GET /api/servicios/{id}
@Data
public class ServicioDTO {
    private Long id;
    private String titulo;
    private Integer precio;
    private Boolean activo;
}
