package cl.nutrivida.atenciones.dto;

import lombok.Data;

// Lo que responde el microservicio usuarios en GET /api/nutricionistas/{id}
@Data
public class NutricionistaDTO {
    private Long id;
    private Long idUsuario;
    private String nombre;
    private Boolean activo;
}
