package cl.nutrivida.atenciones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtencionesApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtencionesApplication.class, args);
	}

}
