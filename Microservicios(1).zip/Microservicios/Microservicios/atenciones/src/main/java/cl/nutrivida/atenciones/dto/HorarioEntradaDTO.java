package cl.nutrivida.atenciones.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalTime;

// Entrada para agregar un bloque de atencion a un nutricionista
@Data
public class HorarioEntradaDTO {

    @NotNull(message = "Debe indicar el nutricionista.")
    private Long idNutricionista;

    @NotNull(message = "Debe indicar la hora del bloque.")
    private LocalTime hora;
}
